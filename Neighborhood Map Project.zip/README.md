This is the neighbor hood map project for my neighborhood.

To begin, unzip the folder and oepn the file main.html in your favorite browser.

From here you can toggle the menu and click show spots to explore the neighborhood. Having utilized the Wiki Api some of the listings will show links to there corrisponding wikipedia pages which you can follow if you would like to learn more.

Google Maps Api is the main part of this page and functions just like the application, just minus a few of the bells and whistles.

Finally, Knockout.JS is the glue that ties it all together into a functioning and exciting app.

Enjoy! I highly recommend Joe Jost's if you are ever around, don't be afraid to try their pickled eggs!